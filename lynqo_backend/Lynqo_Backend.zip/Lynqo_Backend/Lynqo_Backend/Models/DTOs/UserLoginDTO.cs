﻿namespace Lynqo_Backend.Models.DTOs
{
    public class UserLoginDTO
    {
        public string UsernameOrEmail { get; set; }
        public string Password { get; set; }
    }

}

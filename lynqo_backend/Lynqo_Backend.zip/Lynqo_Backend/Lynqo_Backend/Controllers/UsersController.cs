﻿using Microsoft.AspNetCore.Mvc;
using Lynqo_Backend.Data;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Linq;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly LynqoDbContext _context;
    public UserController(LynqoDbContext context) { _context = context; }

    [HttpGet("{username}")]
    public async Task<IActionResult> GetUser(string username)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
        if (user == null) return NotFound();
        return Ok(new
        {
            user.Username,
            user.DisplayName,
            user.Email,
            user.Hearts,
            user.Coins,
            user.IsPremium,
            user.Role,
            user.CreatedAt
        });
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Lynqo_Backend.Models;
namespace Lynqo_Backend.Data;

public class LynqoDbContext : DbContext
{
    public LynqoDbContext(DbContextOptions<LynqoDbContext> options) : base(options) { }
    public DbSet<User> Users { get; set; }
    public DbSet<Setting> Settings { get; set; }
    // Add other tables...

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>()
            .Property(u => u.CreatedAt)
            .HasColumnName("created_at");
        // Map other case/underscore fields as needed
    }
}
